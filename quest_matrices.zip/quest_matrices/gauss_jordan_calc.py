import numpy as np

# Función para imprimir la matriz aumentada
def imprimir_matriz(matriz):
    filas, columnas = matriz.shape
    for i in range(filas):
        fila = ["{:.2f}".format(matriz[i, j]) for j in range(columnas)]
        print("  ".join(fila))

# Función para realizar la eliminación de Gauss-Jordan
def gauss_jordan(matriz_aumentada):
    filas, columnas = matriz_aumentada.shape
    
    for i in range(filas):
        # Hacer el pivote 1
        pivote = matriz_aumentada[i, i]
        if pivote == 0:
            continue  # Si el pivote es 0, continuar
        matriz_aumentada[i] = matriz_aumentada[i] / pivote
        
        # Hacer ceros en las otras filas
        for j in range(filas):
            if i != j:
                factor = matriz_aumentada[j, i]
                matriz_aumentada[j] = matriz_aumentada[j] - factor * matriz_aumentada[i]

    return matriz_aumentada

# Función principal para resolver el sistema
def resolver_sistema():
    print("Ingrese el sistema de ecuaciones (incluyendo las constantes). Si una constante es 0, simplemente ingrese 0.")
    # Dimensiones de la matriz aumentada (3 ecuaciones con 3 incógnitas)
    filas = 3
    columnas = 4
    matriz_aumentada = []

    for i in range(filas):
        ecuacion = list(map(float, input(f"Ingrese los coeficientes de la ecuación {i+1} (x1, x2, x3, constante) separados por espacios: ").split()))
        matriz_aumentada.append(ecuacion)
    
    matriz_aumentada = np.array(matriz_aumentada)

    print("\nMatriz aumentada original:")
    imprimir_matriz(matriz_aumentada)

    # Aplicar el método de Gauss-Jordan
    matriz_resuelta = gauss_jordan(matriz_aumentada.copy())

    print("\nMatriz aumentada después de Gauss-Jordan:")
    imprimir_matriz(matriz_resuelta)

    # Extraer las soluciones
    soluciones = matriz_resuelta[:, -1]
    print("\nLas soluciones son:")
    for i in range(filas):
        print(f"x{i+1} = {soluciones[i]:.2f}")

# Ejecutar el programa
resolver_sistema()
