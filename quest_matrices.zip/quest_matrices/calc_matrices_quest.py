import numpy as np

# Función para mostrar el menú
def mostrar_menu():
    print("\nMenú:")
    print("1. Cargar Matriz A")
    print("2. Cargar Matriz B")
    print("3. Operación: 3A")
    print("4. Operación: 4B")
    print("5. Sumar A + B")
    print("6. Multiplicar B x A")
    print("7. Salir")
    
# Función para cargar una matriz
def cargar_matriz(nombre):
    filas = int(input(f"Ingrese el número de filas para la matriz {nombre}: "))
    columnas = int(input(f"Ingrese el número de columnas para la matriz {nombre}: "))
    matriz = []
    for i in range(filas):
        fila = list(map(int, input(f"Ingrese los elementos de la fila {i+1} separados por espacios: ").split()))
        matriz.append(fila)
    return np.array(matriz)

# Función para ejecutar las operaciones
def ejecutar_operaciones():
    matriz_a = None
    matriz_b = None

    while True:
        mostrar_menu()
        opcion = input("\nSeleccione una opción: ")

        if opcion == "1":
            matriz_a = cargar_matriz("A")
            print(f"Matriz A cargada:\n{matriz_a}")
        elif opcion == "2":
            matriz_b = cargar_matriz("B")
            print(f"Matriz B cargada:\n{matriz_b}")
        elif opcion == "3":
            if matriz_a is not None:
                print(f"Resultado de 3A:\n{3 * matriz_a}")
            else:
                print("Primero debe cargar la matriz A.")
        elif opcion == "4":
            if matriz_b is not None:
                print(f"Resultado de 4B:\n{4 * matriz_b}")
            else:
                print("Primero debe cargar la matriz B.")
        elif opcion == "5":
            if matriz_a is not None and matriz_b is not None:
                if matriz_a.shape == matriz_b.shape:
                    print(f"Resultado de A + B:\n{matriz_a + matriz_b}")
                else:
                    print("Las matrices deben tener las mismas dimensiones para sumarse.")
            else:
                print("Primero debe cargar ambas matrices.")
        elif opcion == "6":
            if matriz_a is not None and matriz_b is not None:
                if matriz_b.shape[1] == matriz_a.shape[0]:
                    print(f"Resultado de B x A:\n{np.dot(matriz_b, matriz_a)}")
                else:
                    print("Las dimensiones de las matrices no son compatibles para la multiplicación.")
            else:
                print("Primero debe cargar ambas matrices.")
        elif opcion == "7":
            print("Saliendo del programa.")
            break
        else:
            print("Opción no válida. Intente de nuevo.")

# Ejecutar el programa
ejecutar_operaciones()
